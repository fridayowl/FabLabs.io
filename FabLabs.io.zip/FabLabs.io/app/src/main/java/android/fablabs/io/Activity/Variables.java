package android.fablabs.io.Activity;

import java.util.ArrayList;
import java.util.List;

public class Variables {

    public  static String  USERID= "UID";
    public  static String USEREMAILID="USEREMAILID";
    public static  String ACCOUNTCREATED= "null";
    public  static  String FLOW = "FLOW";

    //personal data

    public static  String DISPLAYNAME="DISPLAYNAME";
    public  static String PROFILEURl = "PROFILEIMAGE";
    public  static  String UNIQUEID="UNIQUEID";
    public  static String  GIVENNAME= "GIVENNAME";
    public  static  String USERMODE="USERMODE";
    public static String DATABASEID="databaseid";
    public  static  String SELECTEDDATE= "selecteddate";
    public  static  String dateselected= "dateselected";


    //
    public  static String  USERSINFODB = "USERSINFODB";
    public  static String  USERSORDERDB ="USERSORDERDB";
    public  static String  ORDERDB = "ORDERDB";
    public  static String   ICONSUMABLE= " ICONSUMABLE";
    public static  String ITOOLS="ITOOLS";
    public static String  IMACHINES="IMACHINES";
    public  static String MAKERS = "MAKERS";



    //shared preference

    public  static  String DEFAUlTDATA="Default.data";


    //selected List

    public static List<String> selectedList1 = new ArrayList<>();
    public  static List<String> selectedList2= new ArrayList<>();
    public static List<String> selectedList3 = new ArrayList<>();
    public static List<String> selectedList4 = new ArrayList<>();
}
