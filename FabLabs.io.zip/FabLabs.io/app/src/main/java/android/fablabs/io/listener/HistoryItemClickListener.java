package android.fablabs.io.listener;

import android.fablabs.io.model.Myhistorymodel;

public interface HistoryItemClickListener {
  void onItemClicked(Myhistorymodel myhistorymodel);
}
